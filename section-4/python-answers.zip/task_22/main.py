from pathlib import Path
text = Path("input.txt").read_text(encoding="utf-8")
Path("copy.txt").write_text(text, encoding="utf-8")
print(Path("copy.txt").read_text(encoding="utf-8").strip())
