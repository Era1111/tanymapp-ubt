n = int(input())
if n > 0:
    print("Оң")
elif n < 0:
    print("Теріс")
else:
    print("Нөл")
