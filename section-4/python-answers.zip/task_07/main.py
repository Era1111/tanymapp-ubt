year = int(input())
leap = year % 400 == 0 or (year % 4 == 0 and year % 100 != 0)
print("Иә" if leap else "Жоқ")
