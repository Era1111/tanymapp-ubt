try:
    with open("input.txt", encoding="utf-8") as f:
        print(f.read().strip())
except FileNotFoundError:
    print("Файл табылмады")
