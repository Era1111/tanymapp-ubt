with open("input.txt", encoding="utf-8") as f:
    numbers = list(map(int, f.read().split()))
print(sum(numbers))
