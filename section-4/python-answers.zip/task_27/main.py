with open("input.txt", encoding="utf-8") as f:
    for line in f:
        name, score = line.split()
        if int(score) >= 90:
            print(name)
