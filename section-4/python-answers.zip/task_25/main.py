with open("input.txt", encoding="utf-8") as f:
    scores = [int(line) for line in f if line.strip()]
print(sum(score >= 50 for score in scores))
