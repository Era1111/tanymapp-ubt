with open("input.txt", encoding="utf-8") as f:
    numbers = list(map(int, f.read().split()))
print("Жоғары" if max(numbers) > 100 else "Қалыпты")
