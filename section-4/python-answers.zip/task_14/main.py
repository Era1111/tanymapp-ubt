from pathlib import Path
lines = Path("input.txt").read_text(encoding="utf-8").splitlines()
print(len(lines))
