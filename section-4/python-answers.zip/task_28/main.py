with open("input.txt", encoding="utf-8") as f:
    numbers = list(map(int, f.read().split()))
result = f"{max(numbers)} {min(numbers)}"
with open("answer.txt", "w", encoding="utf-8") as f:
    f.write(result)
print(result)
