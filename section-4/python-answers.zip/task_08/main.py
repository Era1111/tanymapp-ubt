a, b, c = map(int, input().split())
ok = min(a, b, c) > 0 and a + b > c and a + c > b and b + c > a
print("Иә" if ok else "Жоқ")
