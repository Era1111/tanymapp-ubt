with open("input.txt", encoding="utf-8") as f:
    words = f.read().split()
print(len(words))
