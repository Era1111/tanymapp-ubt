with open("log.txt", "a", encoding="utf-8") as f:
    f.write("Аяқталды\n")
with open("log.txt", encoding="utf-8") as f:
    print(f.read().strip())
