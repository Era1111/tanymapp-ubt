from pathlib import Path
text = Path("input.txt").read_text(encoding="utf-8")
print(text.strip())
