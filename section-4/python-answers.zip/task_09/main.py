price, count = map(int, input().split())
total = price * count
if total >= 10000:
    total = total * 90 // 100
print(total)
