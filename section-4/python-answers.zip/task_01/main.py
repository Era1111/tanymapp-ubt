n = int(input())
print("Жұп" if n % 2 == 0 else "Тақ")
