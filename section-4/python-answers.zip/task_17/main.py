with open("input.txt", encoding="utf-8") as f:
    numbers = map(int, f.read().split())
print(sum(1 for n in numbers if n % 2 == 0))
