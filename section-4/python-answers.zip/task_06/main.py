score = int(input())
if not 0 <= score <= 100:
    print("Қате")
elif score >= 90:
    print("A")
elif score >= 75:
    print("B")
elif score >= 50:
    print("C")
else:
    print("D")
