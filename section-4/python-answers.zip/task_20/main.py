with open("input.txt", encoding="utf-8") as source:
    numbers = list(map(int, source.read().split()))
with open("output.txt", "w", encoding="utf-8") as target:
    for n in numbers:
        target.write(f"{n*n}\n")
print(open("output.txt", encoding="utf-8").read().strip())
