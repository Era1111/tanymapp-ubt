x = int(input())
print("Иә" if 10 <= x <= 99 else "Жоқ")
