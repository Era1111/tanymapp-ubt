with open("input.txt", encoding="utf-8") as f:
    print(f.readline().strip())
