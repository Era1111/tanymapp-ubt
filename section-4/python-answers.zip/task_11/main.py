password = input().strip()
has_digit = any(ch.isdigit() for ch in password)
print("Жарамды" if len(password) >= 8 and has_digit else "Жарамсыз")
