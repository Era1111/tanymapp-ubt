with open("input.txt", encoding="utf-8") as f:
    numbers = map(int, f.read().split())
result = " ".join(str(n) for n in numbers if n > 0)
with open("result.txt", "w", encoding="utf-8") as f:
    f.write(result)
print(result)
