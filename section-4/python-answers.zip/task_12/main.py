units = int(input())
if units <= 100:
    cost = units * 20
else:
    cost = 100 * 20 + (units - 100) * 30
print(cost)
